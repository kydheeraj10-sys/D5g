# 5G DNS Quick Switch

Android app starter project for OnePlus 13 / ARM64 devices.

## Features
- Two Quick Settings tiles: 4G/5G settings shortcut and DNS settings shortcut.
- DNS provider picker for Google, Cloudflare, and AdGuard Private DNS hostnames.
- Wireless debugging setup guide. Android still requires the user to enable Wireless debugging and approve pairing in system settings.
- No root or Shizuku dependency.

## Important platform limitations
An ordinary third-party app cannot silently force the preferred cellular network type (4G/5G) or change Android Private DNS globally without privileged access. This app therefore opens the appropriate system settings. Wireless debugging pairing is user-authorized; this starter does not silently obtain ADB privileges or run privileged commands.

## Build
Open this repository on GitHub and use the included GitHub Actions workflow (`Android APK`) to build a debug APK. The workflow uploads the APK as an artifact.
